"""SQL Injection module with high performance and accuracy"""

__version__ = "0.1"



from .main import SQLInjectionDetecor
from .exceptions import SQLInjectionException as SQLInjectionException

